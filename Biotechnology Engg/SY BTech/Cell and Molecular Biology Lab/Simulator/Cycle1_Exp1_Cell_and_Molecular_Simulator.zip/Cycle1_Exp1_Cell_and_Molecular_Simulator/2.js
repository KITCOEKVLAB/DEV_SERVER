var lineno = 0, linestotal = 30

function startsimulation() {
    document.getElementById('Start').innerHTML = "Next"
    var button = document.querySelector('.btn-success')
    button.classList.add('btn-info')

    procedure()

}

lst = ['Step 1. Take half of a young dry leaf of Tulsi & Neem & cut it into small pieces(see Fig.1 for illustration)then grind it using a mortar & pestle in 400ml of the extraction buffer.',
    'Step 2. Add more buffer until it reaches a final volume of 1200ml in order to have enough homogenate to place into a microfuge tube.',
    'Step 3. Spin (13,500 rpm, 4 min, RT) using a micro centrifuge.',
    'Step 4. Transfer the supernatant into a new microfuge tube & add an equal volume of isopropanol (500ml in our study) & mix gently by inversion. Place the mixture on ice for 5min.',
    'Step 5.Spin (13,500 rpm, 4 min, RT)using a microcentrifuge.',
    'Step 6. Discard the ethanol. Blot away the excess ethanol from the pellet by inverting/placing it on a clean paper-towel. Let the pellet air-dry.',
    'Step 7.Dissolve the DNA in 50ml ddH2O & store it at 4 degree celsius for immediate use or-20 degree celsius for long term storage',
    'Step 8.Add 15ml 1x gel loading buffer in sample.',
    'Step 9.Run 20ml sample on 1% agarose gel stained with ethidium bromide and load sample with total DNA extraction.'
    ]

function procedure() {
    lineno = lineno + 1
    str = 'line' + lineno
    if (str == 'line1') {
        document.getElementById('procedure-image').src = 'step 1-1.png'
        
        const text2 = document.querySelector('#procedure')
        text2.innerHTML = '<em>' + lst[0] + '</em>'
    }
    if (str == 'line2') {
        document.getElementById('procedure-image').src = 'step 1-2.png'
        const text2 = document.querySelector('#procedure')
        text2.innerHTML = '<em>' + lst[0] + '</em>'
    }
    if (str == 'line3') {
        document.getElementById('procedure-image').src = 'step 1-3.png'
        const text2 = document.querySelector('#procedure')
        text2.innerHTML = '<em>' + lst[0] + '</em>'
    }
    if (str == 'line4') {
        document.getElementById('procedure-image').src = 'step 1-4.png'
        const text2 = document.querySelector('#procedure')
        text2.innerHTML = '<em>' + lst[0] + '</em>'
    }
    if (str == 'line5') {
        document.getElementById('procedure-image').src = 'step 1-5.png'
        const text2 = document.querySelector('#procedure')
        text2.innerHTML = '<em>' + lst[0] + '</em>'
    }

if (str == 'line6') {
        document.getElementById('procedure-image').src = 'step 1-6.png'
        const text2 = document.querySelector('#procedure')
        text2.innerHTML = '<em>' + lst[0] + '</em>'
    }

     if (str == 'line7') {
        document.getElementById('procedure-image').src = 'step 1-7.png'
        const text2 = document.querySelector('#procedure')
        text2.innerHTML = '<em>' + lst[0] + '</em>'
    }

     if (str == 'line8') {
        document.getElementById('procedure-image').src = 'step 2-1.png'
        const text2 = document.querySelector('#procedure')
        text2.innerHTML = '<em>' + lst[1] + '</em>'
    }

     if (str == 'line9') {
        document.getElementById('procedure-image').src = 'step 2-2.png'
        const text2 = document.querySelector('#procedure')
        text2.innerHTML = '<em>' + lst[1] + '</em>'
    }

     if (str == 'line10') {
        document.getElementById('procedure-image').src = 'step 2-3.png'
        const text2 = document.querySelector('#procedure')
        text2.innerHTML = '<em>' + lst[1] + '</em>'
    }

    if (str == 'line11') {
        document.getElementById('procedure-image').src = 'step 3-2.png'
        const text2 = document.querySelector('#procedure')
        text2.innerHTML = '<em>' + lst[1] + '</em>'
    }


     if (str == 'line12') {
        document.getElementById('procedure-image').src = 'step 3-1.png'
        const text2 = document.querySelector('#procedure')
        text2.innerHTML = '<em>' + lst[2] + '</em>'
    }

     if (str == 'line12') {
        document.getElementById('procedure-image').src = 'step 3-2.png'
        const text2 = document.querySelector('#procedure')
        text2.innerHTML = '<em>' + lst[2] + '</em>'
    }

     if (str == 'line13') {
        document.getElementById('procedure-image').src = 'step 3-3.png'
        const text2 = document.querySelector('#procedure')
        text2.innerHTML = '<em>' + lst[2] + '</em>'
    }


     if (str == 'line14') {
        document.getElementById('procedure-image').src = 'step 3-4.png'
        const text2 = document.querySelector('#procedure')
        text2.innerHTML = '<em>' + lst[2] + '</em>'
    }


     if (str == 'line15') {
        document.getElementById('procedure-image').src = 'step 4-1.png'
        const text2 = document.querySelector('#procedure')
        text2.innerHTML = '<em>' + lst[3] + '</em>'
    }


     if (str == 'line16') {
        document.getElementById('procedure-image').src = 'step 4-2.png'
        const text2 = document.querySelector('#procedure')
        text2.innerHTML = '<em>' + lst[3] + '</em>'
    }


     if (str == 'line17') {
        document.getElementById('procedure-image').src = 'step 4-3.png'
        const text2 = document.querySelector('#procedure')
        text2.innerHTML = '<em>' + lst[3] + '</em>'
    }

if (str == 'line18') {
        document.getElementById('procedure-image').src = 'step 4-4.png'
        const text2 = document.querySelector('#procedure')
        text2.innerHTML = '<em>' + lst[3] + '</em>'
    }

    if (str == 'line19') {
        document.getElementById('procedure-image').src = 'step 5-4.png'
        const text2 = document.querySelector('#procedure')
        text2.innerHTML = '<em>' + lst[4] + '</em>'
    }

    if (str == 'line20') {
        document.getElementById('procedure-image').src = 'step 8-1.png'
        const text2 = document.querySelector('#procedure')
        text2.innerHTML = '<em>' + lst[5] + '</em>'
    }

    if (str == 'line21') {
        document.getElementById('procedure-image').src = 'step 8-2.png'
        const text2 = document.querySelector('#procedure')
        text2.innerHTML = '<em>' + lst[5] + '</em>'
    }

    if (str == 'line22') {
        document.getElementById('procedure-image').src = 'step 8-3.png'
        const text2 = document.querySelector('#procedure')
        text2.innerHTML = '<em>' + lst[5] + '</em>'
    }
     if (str == 'line23') {
        document.getElementById('procedure-image').src = 'step 9-1.png'
        const text2 = document.querySelector('#procedure')
        text2.innerHTML = '<em>' + lst[6] + '</em>'
    }
     if (str == 'line24') {
        document.getElementById('procedure-image').src = 'step 9-2.png'
        const text2 = document.querySelector('#procedure')
        text2.innerHTML = '<em>' + lst[6] + '</em>'
    }
     if (str == 'line25') {
        document.getElementById('procedure-image').src = 'step 6-3.png'
        const text2 = document.querySelector('#procedure')
        text2.innerHTML = '<em>' + lst[6] + '</em>'
    }

    if (str == 'line26') {
        document.getElementById('procedure-image').src = 'step 10.png'
        const text2 = document.querySelector('#procedure')
        text2.innerHTML = '<em>' + lst[7] + '</em>'
    }

    

    if (str == 'line27') {
        document.getElementById('procedure-image').src = 'step 3-2.png'
        const text2 = document.querySelector('#procedure')
        text2.innerHTML = '<em>' + lst[7] + '</em>'
    }

   
    
   if (str == 'line28') {
        document.getElementById('procedure-image').src = 'step 10-2.png'
        const text2 = document.querySelector('#procedure')
        text2.innerHTML = '<em>' + lst[8] + '</em>'
    }



    if (str == 'line29') {
        document.getElementById('procedure-image').src = 'step 10-3.png'
        const text2 = document.querySelector('#procedure')
        text2.innerHTML = '<em>' + lst[8] + '</em>'



        document.getElementById('Start').innerHTML = "Re run"
        var button = document.querySelector('.btn-success')
        button.classList.add('btn-danger')
        document.getElementById('complete').innerHTML = 'Simulation Complete <i class="fa fa-thumbs-up"></i>'
        document.body.classList.add('background')
    }



    if (str == 'line30') {
        lineno = 0
        window.location.reload()
    }


}

function reset() {
    document.getElementById('Start').innerHTML = "Start"
    var button = document.querySelector('.btn-success')
    button.classList.remove('btn-info')
    window.location.reload()
}