var descr=document.getElementById('step1')
var nextBtn=document.getElementById('next')

descr.innerHTML="Consider two point X and Y at any distance D and place the tripod stand with dumpy level in between X and Y."

var counter = 0
nextBtn.addEventListener('click',function(){
    counter = counter+1
    let currentStep = "step"+String(counter)

    if(currentStep=="step1"){
        document.getElementById(currentStep).style.visibility = "hidden"
        document.getElementById('snap1').style.visibility = "hidden"
        document.getElementById('step2').style.visibility = "visible"
        document.getElementById('snap2').style.visibility = "visible"
    }
    if(currentStep=="step2"){
        document.getElementById(currentStep).style.visibility = "hidden"
        document.getElementById('step3').style.visibility = "visible"
        document.getElementById('snap2').style.visibility = "hidden"
        document.getElementById('gif1').style.visibility = "visible"
        document.getElementById('info').style.visibility = "visible"
    }
    if(currentStep=="step3"){
        document.getElementById(currentStep).style.visibility = "hidden"
        document.getElementById('step4').style.visibility = "visible"
        document.getElementById('gif1').style.visibility = "hidden"
        document.getElementById('info').style.visibility = "hidden"
        document.getElementById('snap3').style.visibility = "visible"
    }
    
    if(currentStep=="step4"){
        document.getElementById(currentStep).style.visibility = "hidden"    
        document.getElementById('step5').style.visibility = "visible"
        document.getElementById('gif1').style.visibility = "hidden"
        document.getElementById('snap3').style.visibility = "visible"
    }
    if(currentStep=="step5"){
        document.getElementById(currentStep).style.visibility = "hidden"    
        document.getElementById('step6').style.visibility = "visible"
        document.getElementById('snap3').style.visibility = "visible"
    }
    if(currentStep=="step6"){
        document.getElementById(currentStep).style.visibility = "hidden"    
        document.getElementById('step7').style.visibility = "visible"
        document.getElementById('snap3').style.visibility= "hidden"
        document.getElementById('formula').style.visibility="visible"
    }
    
        
})