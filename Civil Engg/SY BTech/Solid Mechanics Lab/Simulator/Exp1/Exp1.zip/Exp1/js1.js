var descr=document.getElementById('step1')
var nextBtn=document.getElementById('next')

descr.innerHTML="MS-BAR"

var counter = 0
nextBtn.addEventListener('click',function(){
    counter = counter+1
    let currentStep = "step"+String(counter)

    if(currentStep=="step1"){
        document.getElementById(currentStep).style.visibility = "hidden"
        document.getElementById('img1').style.visibility = "hidden"
        document.getElementById('step2').style.visibility = "visible"
        document.getElementById('img2').style.visibility = "visible"
    }
    if(currentStep=="step2"){
        document.getElementById(currentStep).style.visibility = "hidden"
        document.getElementById('step3').style.visibility = "visible"
        document.getElementById('img2').style.visibility = "hidden"
        document.getElementById('img3').style.visibility = "visible"
    }
    /*if(currentStep=="step3"){
        document.getElementById(currentStep).style.visibility = "hidden"
        //document.getElementById('step4').style.visibility = "visible"
        document.getElementById('img2').style.visibility = "hidden"
        
    }*/
    
   
    
        
})