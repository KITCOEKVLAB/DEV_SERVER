var val=1;

sessionStorage.setItem('val',val)

function navnext(){
    
    if (val==1){
        document.getElementById('canvas0').style.visibility="hidden";
        document.getElementById('step0').style.visibility="hidden";
        document.getElementById('canvas1').style.visibility="visible"
        document.getElementById('step1').style.visibility="visible"
        val=val+1;
        sessionStorage.setItem('val',val)
        
    }
    else if (val==2){
        document.getElementById('canvas1').style.visibility="hidden";
        document.getElementById('step1').style.visibility="hidden";
        document.getElementById('canvas2').style.visibility="visible";
        document.getElementById('step2').style.visibility="visible";
        val=val+1;
        sessionStorage.setItem('val',val)
    }
    else if (val==3){
        document.getElementById('canvas2').style.visibility="hidden";
        document.getElementById('step2').style.visibility="hidden";
        document.getElementById('canvas3').style.visibility="visible";
        document.getElementById('step3').style.visibility="visible";
        val=val+1;
        sessionStorage.setItem('val',val)
    }
    else if (val==4){
        document.getElementById('canvas3').style.visibility="hidden";
        document.getElementById('step3').style.visibility="hidden";
        document.getElementById('canvas4').style.visibility="visible";
        document.getElementById('step4').style.visibility="visible";
        val=val+1;
        sessionStorage.setItem('val',val)
    }
   
}

function navprev(){
    if (val==2){
        document.getElementById('canvas0').style.visibility="visible";
        document.getElementById('step0').style.visibility="visible";
        document.getElementById('canvas1').style.visibility="hidden";
        document.getElementById('step1').style.visibility="hidden";
        val=val-1;
        sessionStorage.setItem('val',val)
        
    }
    else if (val==3){
        document.getElementById('canvas1').style.visibility="visible";
        document.getElementById('step1').style.visibility="visible";
        document.getElementById('canvas2').style.visibility="hidden";
        document.getElementById('step2').style.visibility="hidden";
        val=val-1;
        sessionStorage.setItem('val',val)
        
    }
    else if (val==4){
        document.getElementById('canvas2').style.visibility="visible";
        document.getElementById('step2').style.visibility="visible";
        document.getElementById('canvas3').style.visibility="hidden";
        document.getElementById('step3').style.visibility="hidden";
        val=val-1;
        sessionStorage.setItem('val',val)
        
    }
    else if (val==5){
        document.getElementById('canvas3').style.visibility="visible";
        document.getElementById('step3').style.visibility="visible";
        document.getElementById('canvas4').style.visibility="hidden";
        document.getElementById('step4').style.visibility="hidden";
        val=val-1;
        sessionStorage.setItem('val',val)
        
    }
}